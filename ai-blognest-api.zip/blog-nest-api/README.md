# AI Blog Nest API

A blog REST API with built-in AI writing tools, built with **NestJS 11**, **TypeORM** and **SQLite** (via `sql.js`, so no native
compilation or database server is needed), with JWT authentication and Swagger docs.

## Quick start

```bash
npm install
npm run seed        # optional: sample users + posts
npm run start:dev   # http://localhost:3000/api
```

* Swagger UI: http://localhost:3000/docs
* Config lives in `.env` (see `.env.example`). **Change `JWT_SECRET` before deploying.**
* Optional: put your key in `.env` as `ANTHROPIC_API_KEY=...` to switch the AI endpoints from the offline provider to Claude.
* The database is a single file at `data/blog.sqlite` (created on first run).

Seeded logins (password `password123`): `admin@example.com` (admin), `jane@example.com` (user).

## Features

* Register / login with JWT bearer tokens. **The first account registered becomes the admin.**
* Posts with auto-generated unique slugs, excerpts, tags, drafts and published state.
  Drafts are visible only to their author and admins.
* Search (`q`), tag filter (`tag`), author filter (`authorId`) and pagination (`page`, `limit`).
* Comments on posts; authors and admins can delete them.
* **AI writing tools** (`/api/ai/*`): draft a whole post, summarize, suggest tags and titles, improve
  text, and auto-fill a post's excerpt + tags. Runs on Claude when `ANTHROPIC_API_KEY` is set, and on a free
  offline heuristic provider otherwise, so everything works out of the box.
* Input validation (unknown fields are rejected), password hashing (bcrypt), no email/hash leaks.

## Endpoints (all under `/api`)

| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| GET | `/health` | – | Liveness check |
| POST | `/auth/register` | – | `{ email, username, password }` → `{ accessToken, user }` |
| POST | `/auth/login` | – | `{ email, password }` → `{ accessToken, user }` |
| GET | `/auth/me` | required | Current user |
| GET | `/posts` | optional | `?page&limit&q&tag&authorId` → `{ items, meta }` |
| GET | `/posts/:idOrSlug` | optional | Numeric id or slug |
| POST | `/posts` | required | `{ title, content, excerpt?, published?, tags? }` |
| PATCH | `/posts/:id` | author/admin | Any of the create fields |
| DELETE | `/posts/:id` | author/admin | Also deletes its comments |
| GET | `/posts/:postId/comments` | optional | Oldest first |
| POST | `/posts/:postId/comments` | required | `{ content }` |
| DELETE | `/comments/:id` | author/admin | |
| GET | `/tags` | – | Tags of published posts with `postCount` |
| GET | `/ai/status` | required | Active provider, model and `keySource` (`user`, `server`, `none`) |
| GET | `/ai/key` | required | Do I have my own key saved? (`{ hasKey, keyHint: "...abcd", model }`) |
| PUT | `/ai/key` | required | `{ apiKey, model?, validate? }` save/replace **your** Anthropic key |
| PATCH | `/ai/key` | required | `{ model }` change the model used with your key (`null` = default) |
| DELETE | `/ai/key` | required | Remove your key |
| POST | `/ai/generate-post` | required | `{ topic, tone?, length?, audience?, keywords? }` → `{ title, excerpt, content, tags }` (not saved) |
| POST | `/ai/summarize` | required | `{ text \| postId, maxSentences? }` → `{ summary }` |
| POST | `/ai/suggest-tags` | required | `{ text \| postId, max? }` → `{ tags }` |
| POST | `/ai/suggest-titles` | required | `{ text \| postId, count? }` → `{ titles }` |
| POST | `/ai/improve` | required | `{ text, goal? }` (`grammar`, `clarity`, `concise`, `friendly`, `professional`) → `{ text }` |
| POST | `/ai/posts/:id/enrich` | required | `{ apply? }` → excerpt + merged tags; `apply: true` saves them (author/admin) |

Send the token as `Authorization: Bearer <accessToken>`.

### Example

```bash
curl -X POST localhost:3000/api/auth/register -H 'content-type: application/json' \
  -d '{"email":"me@example.com","username":"me","password":"password123"}'

curl -X POST localhost:3000/api/posts -H 'content-type: application/json' \
  -H "authorization: Bearer $TOKEN" \
  -d '{"title":"My first post","content":"Hello!","tags":["intro"],"published":true}'
```

## AI features

Every AI response includes `provider` and `model`, so clients can tell what produced the text.

| Provider | When | Quality |
| --- | --- | --- |
| `anthropic` | `ANTHROPIC_API_KEY` is set (or `AI_PROVIDER=anthropic`) | Real model-written text (default model `claude-sonnet-5-5`, change with `AI_MODEL`) |
| `local` | no key (or `AI_PROVIDER=local`) | Offline and free: extractive summaries, keyword tags/titles, rule-based clean-up, template drafts |

Design notes:

* Post-based calls (`postId`) go through the normal post visibility rules: other people's drafts return 404,
  and only an author/admin can `apply` enrichment.
* Whatever a provider returns is normalized to what `POST /posts` accepts (tags <= 30 chars, excerpt <= 300 ...),
  so a generated draft can be sent straight to `POST /api/posts`.
* User text is wrapped in `<content>` tags and the system prompt tells the model to treat it as data
  (basic prompt-injection hygiene). Provider error bodies are never forwarded to clients (502 only).
* Per-user rate limit: `AI_RATE_LIMIT_PER_MINUTE` (default 20, in memory; use Redis if you run several instances).

```bash
# 1. Draft a post, 2. save it
curl -s -X POST localhost:3000/api/ai/generate-post -H 'content-type: application/json' \
  -H "authorization: Bearer $TOKEN" \
  -d '{"topic":"getting started with Docker","tone":"friendly","length":"medium"}' > draft.json

curl -s -X POST localhost:3000/api/posts -H 'content-type: application/json' \
  -H "authorization: Bearer $TOKEN" \
  -d "$(python3 -c 'import json;d=json.load(open("draft.json"));print(json.dumps({k:d[k] for k in ("title","content","excerpt","tags")}))')"

# Auto-fill excerpt + tags of an existing post
curl -s -X POST localhost:3000/api/ai/posts/1/enrich -H 'content-type: application/json' \
  -H "authorization: Bearer $TOKEN" -d '{"apply":true}'
```

### Using your own API key

Each user can plug in their own Anthropic key, with no server restart or `.env` edit:

```bash
curl -X PUT localhost:3000/api/ai/key -H 'content-type: application/json' \
  -H "authorization: Bearer $TOKEN" -d '{"apiKey":"sk-ant-...","model":"claude-sonnet-5-5"}'
curl localhost:3000/api/ai/key -H "authorization: Bearer $TOKEN"     # { "hasKey": true, "keyHint": "...abcd" }
curl -X DELETE localhost:3000/api/ai/key -H "authorization: Bearer $TOKEN"
```

* Priority for each request: **your key** → server `ANTHROPIC_API_KEY` → offline provider. Other users are unaffected.
* The key is verified with a 1-token call before saving (`"validate": false` skips it). Invalid keys and unknown
  model names are rejected with 400.
* Stored with AES-256-GCM; only the last 4 characters are ever returned. The encryption secret is
  `AI_KEY_ENCRYPTION_SECRET` (falls back to `JWT_SECRET`). **Set it explicitly in production**: if the secret
  changes, saved keys can no longer be decrypted and users must re-enter them (the server then falls back).
* Use HTTPS in production, since the key travels in the request body when saved.

## Scripts

| Script | What it does |
| --- | --- |
| `npm run start:dev` | Run with auto-reload |
| `npm run build` / `npm run start:prod` | Compile to `dist/` and run it |
| `npm run seed` | Insert sample data (run on an empty database) |
| `npm run test:e2e` | End-to-end tests against an in-memory database |

## Project layout

```
src/
  auth/       register, login, JWT guards
  users/      user entity + service
  posts/      post entity, DTOs, service, controller
  comments/   comment entity, service, controller
  tags/       tag entity + listing
  ai/         AI controller/service, rate limiter, providers (anthropic, local)
  common/     slugify, @CurrentUser decorator
test/         e2e tests
```

## Notes for production

* `synchronize: true` (in `src/app.module.ts`) auto-creates tables, which is convenient for development.
  For real data, switch to TypeORM migrations.
* For heavy traffic or several server instances, replace `sql.js` with Postgres/MySQL by changing the
  TypeORM config; the entities need no changes.
