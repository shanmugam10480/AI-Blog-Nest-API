process.env.DATABASE_PATH = ':memory:';
process.env.JWT_SECRET = 'test-secret';

import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { setupApp } from '../src/setup-app';

describe('Blog Nest API (e2e)', () => {
  let app: INestApplication;
  let http: ReturnType<INestApplication['getHttpServer']>;
  let adminToken: string;
  let janeToken: string;
  let bobToken: string;
  let postId: number;
  let postSlug: string;

  const auth = (token: string) => ({ Authorization: `Bearer ${token}` });

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication();
    setupApp(app);
    await app.init();
    http = app.getHttpServer();
  });

  afterAll(async () => {
    await app.close();
  });

  describe('auth', () => {
    it('registers the first user as admin and never leaks the password hash', async () => {
      const res = await request(http)
        .post('/api/auth/register')
        .send({ email: 'Admin@Example.com', username: 'admin', password: 'password123' })
        .expect(201);
      expect(res.body.user).toMatchObject({ email: 'admin@example.com', username: 'admin', role: 'admin' });
      expect(res.body.user.passwordHash).toBeUndefined();
      adminToken = res.body.accessToken;
    });

    it('registers later users as regular users', async () => {
      const res = await request(http)
        .post('/api/auth/register')
        .send({ email: 'jane@example.com', username: 'jane', password: 'password123' })
        .expect(201);
      expect(res.body.user.role).toBe('user');
      janeToken = res.body.accessToken;
    });

    it('rejects duplicate emails and invalid input', async () => {
      await request(http)
        .post('/api/auth/register')
        .send({ email: 'jane@example.com', username: 'jane2', password: 'password123' })
        .expect(409);
      await request(http)
        .post('/api/auth/register')
        .send({ email: 'not-an-email', username: 'x', password: 'short' })
        .expect(400);
    });

    it('logs in with correct credentials only', async () => {
      await request(http)
        .post('/api/auth/login')
        .send({ email: 'jane@example.com', password: 'password123' })
        .expect(200)
        .expect((r) => expect(r.body.accessToken).toBeDefined());
      await request(http)
        .post('/api/auth/login')
        .send({ email: 'jane@example.com', password: 'wrong-password' })
        .expect(401);
    });

    it('returns the current user on /auth/me and 401 without a token', async () => {
      await request(http).get('/api/auth/me').set(auth(janeToken)).expect(200).expect((r) => {
        expect(r.body.username).toBe('jane');
      });
      await request(http).get('/api/auth/me').expect(401);
      await request(http).get('/api/auth/me').set(auth('garbage')).expect(401);
    });
  });

  describe('posts', () => {
    it('requires auth to create a post', async () => {
      await request(http).post('/api/posts').send({ title: 'Nope', content: 'x' }).expect(401);
    });

    it('creates a draft with tags, a slug and an auto excerpt', async () => {
      const res = await request(http)
        .post('/api/posts')
        .set(auth(janeToken))
        .send({ title: 'Hello, World!', content: 'My very first post.', tags: ['NestJS', ' intro ', 'nestjs'] })
        .expect(201);
      expect(res.body).toMatchObject({
        title: 'Hello, World!',
        slug: 'hello-world',
        published: false,
        excerpt: 'My very first post.',
        author: { username: 'jane' },
      });
      expect(res.body.author.email).toBeUndefined();
      expect(res.body.tags.map((t) => t.name).sort()).toEqual(['intro', 'nestjs']);
      postId = res.body.id;
      postSlug = res.body.slug;
    });

    it('generates unique slugs for duplicate titles', async () => {
      const res = await request(http)
        .post('/api/posts')
        .set(auth(janeToken))
        .send({ title: 'Hello, World!', content: 'Another one', published: true })
        .expect(201);
      expect(res.body.slug).toBe('hello-world-2');
    });

    it('hides drafts from anonymous users and other users, but shows them to the author and admin', async () => {
      await request(http).get(`/api/posts/${postId}`).expect(404);
      await request(http).get(`/api/posts/${postSlug}`).set(auth(adminToken)).expect(200);
      await request(http).get(`/api/posts/${postId}`).set(auth(janeToken)).expect(200);

      const anon = await request(http).get('/api/posts').expect(200);
      expect(anon.body.items.map((p) => p.slug)).toEqual(['hello-world-2']);
      const mine = await request(http).get('/api/posts').set(auth(janeToken)).expect(200);
      expect(mine.body.meta.total).toBe(2);
    });

    it('lets only the author or an admin edit; other users get 403', async () => {
      await request(http)
        .post('/api/auth/register')
        .send({ email: 'bob@example.com', username: 'bob', password: 'password123' })
        .expect(201)
        .then((r) => (bobToken = r.body.accessToken));
      // second post (published) belongs to jane
      const list = await request(http).get('/api/posts').expect(200);
      const publishedId = list.body.items[0].id;
      await request(http).patch(`/api/posts/${publishedId}`).set(auth(bobToken)).send({ title: 'Hacked' }).expect(403);
      await request(http).patch(`/api/posts/${publishedId}`).set(auth(adminToken)).send({ content: 'Edited by admin' }).expect(200);
      // Bob can't even see jane's draft
      await request(http).patch(`/api/posts/${postId}`).set(auth(bobToken)).send({ title: 'x1x' }).expect(404);
    });

    it('publishes a draft and replaces its tags', async () => {
      const res = await request(http)
        .patch(`/api/posts/${postId}`)
        .set(auth(janeToken))
        .send({ published: true, tags: ['typescript'] })
        .expect(200);
      expect(res.body.published).toBe(true);
      expect(res.body.tags.map((t) => t.name)).toEqual(['typescript']);
      await request(http).get(`/api/posts/${postSlug}`).expect(200);
    });

    it('validates query params and rejects unknown fields', async () => {
      await request(http).get('/api/posts?limit=1000').expect(400);
      await request(http).post('/api/posts').set(auth(janeToken)).send({ title: 'Valid title', content: 'x', evil: 1 }).expect(400);
    });

    it('supports search, tag filter and pagination', async () => {
      const bySearch = await request(http).get('/api/posts?q=Edited').expect(200);
      expect(bySearch.body.meta.total).toBe(1);

      const byTag = await request(http).get('/api/posts?tag=TypeScript').expect(200);
      expect(byTag.body.items.map((p) => p.id)).toEqual([postId]);
      expect(byTag.body.items[0].tags).toHaveLength(1);

      const page = await request(http).get('/api/posts?limit=1&page=2').expect(200);
      expect(page.body.items).toHaveLength(1);
      expect(page.body.meta).toMatchObject({ total: 2, page: 2, limit: 1, pages: 2 });
    });
  });

  describe('comments & tags', () => {
    let commentId: number;

    it('allows logged-in users to comment and anyone to read', async () => {
      await request(http).post(`/api/posts/${postId}/comments`).send({ content: 'hi' }).expect(401);
      const res = await request(http)
        .post(`/api/posts/${postId}/comments`)
        .set(auth(bobToken))
        .send({ content: 'Nice post!' })
        .expect(201);
      expect(res.body).toMatchObject({ content: 'Nice post!', postId, author: { username: 'bob' } });
      expect(res.body.author.email).toBeUndefined();
      commentId = res.body.id;

      const list = await request(http).get(`/api/posts/${postId}/comments`).expect(200);
      expect(list.body).toHaveLength(1);
    });

    it('only lets the comment author or an admin delete a comment', async () => {
      await request(http).delete(`/api/comments/${commentId}`).set(auth(janeToken)).expect(403);
      await request(http).delete(`/api/comments/${commentId}`).set(auth(bobToken)).expect(204);
      await request(http).delete(`/api/comments/${commentId}`).set(auth(bobToken)).expect(404);
    });

    it('lists tags used by published posts with counts', async () => {
      const res = await request(http).get('/api/tags').expect(200);
      expect(res.body).toEqual([expect.objectContaining({ name: 'typescript', postCount: 1 })]);
    });
  });

  describe('deleting posts', () => {
    it('removes the post together with its comments', async () => {
      await request(http).post(`/api/posts/${postId}/comments`).set(auth(bobToken)).send({ content: 'bye' }).expect(201);
      await request(http).delete(`/api/posts/${postId}`).set(auth(bobToken)).expect(403);
      await request(http).delete(`/api/posts/${postId}`).set(auth(janeToken)).expect(204);
      await request(http).get(`/api/posts/${postId}`).expect(404);
      await request(http).get(`/api/posts/${postId}/comments`).expect(404);
    });
  });

  it('GET /api/health', () => request(http).get('/api/health').expect(200).expect((r) => expect(r.body.status).toBe('ok')));
});
