process.env.DATABASE_PATH = ':memory:';
process.env.JWT_SECRET = 'test-secret';
process.env.AI_RATE_LIMIT_PER_MINUTE = '1000';

import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import { AppModule } from '../src/app.module';
import { decryptKey, encryptKey } from '../src/ai/key-crypto';
import { setupApp } from '../src/setup-app';

const USER_KEY = 'sk-ant-api03-USERSECRETKEY-abcdwxyz';
const SERVER_KEY = 'sk-ant-SERVER-KEY-0000000000';
const bearer = (t: string) => ({ Authorization: `Bearer ${t}` });

async function boot(env: Record<string, string | undefined>) {
  const saved: Record<string, string | undefined> = {};
  for (const [k, v] of Object.entries(env)) {
    saved[k] = process.env[k];
    if (v === undefined) delete process.env[k];
    else process.env[k] = v;
  }
  const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
  const app = moduleRef.createNestApplication();
  setupApp(app);
  await app.init();
  for (const [k, v] of Object.entries(saved)) {
    if (v === undefined) delete process.env[k];
    else process.env[k] = v;
  }
  return app;
}

async function register(app: INestApplication, name: string) {
  const res = await request(app.getHttpServer())
    .post('/api/auth/register')
    .send({ email: `${name}@example.com`, username: name, password: 'password123' })
    .expect(201);
  return res.body.accessToken as string;
}

const reply = (status: number, text = 'ok') =>
  Promise.resolve({ ok: status >= 200 && status < 300, status, json: async () => ({ content: [{ type: 'text', text }] }) } as Response);

describe('bring-your-own API key', () => {
  const realFetch = global.fetch;
  let fetchMock: jest.Mock;
  beforeEach(() => {
    fetchMock = jest.fn();
    global.fetch = fetchMock as any;
  });
  afterEach(() => {
    global.fetch = realFetch;
  });

  describe('without a server key', () => {
    let app: INestApplication;
    let http: ReturnType<INestApplication['getHttpServer']>;
    let me: string;
    let other: string;

    beforeAll(async () => {
      app = await boot({ ANTHROPIC_API_KEY: undefined, AI_PROVIDER: 'auto' });
      http = app.getHttpServer();
      me = await register(app, 'meuser');
      other = await register(app, 'otheruser');
    });
    afterAll(async () => app.close());

    it('requires authentication', async () => {
      await request(http).get('/api/ai/key').expect(401);
      await request(http).put('/api/ai/key').send({ apiKey: USER_KEY }).expect(401);
      await request(http).delete('/api/ai/key').expect(401);
    });

    it('starts with no key and the offline provider', async () => {
      const res = await request(http).get('/api/ai/key').set(bearer(me)).expect(200);
      expect(res.body).toEqual({ hasKey: false });
      const st = await request(http).get('/api/ai/status').set(bearer(me)).expect(200);
      expect(st.body).toMatchObject({ provider: 'local', keySource: 'none' });
    });

    it('rejects malformed keys', async () => {
      await request(http).put('/api/ai/key').set(bearer(me)).send({ apiKey: 'short' }).expect(400);
      await request(http).put('/api/ai/key').set(bearer(me)).send({ apiKey: 'has some spaces in the key value' }).expect(400);
      await request(http).put('/api/ai/key').set(bearer(me)).send({ apiKey: USER_KEY, model: 'bad model!' }).expect(400);
      await request(http).put('/api/ai/key').set(bearer(me)).send({ apiKey: USER_KEY, extra: 1 }).expect(400);
      expect(fetchMock).not.toHaveBeenCalled();
    });

    it('does not save a key Anthropic rejects', async () => {
      fetchMock.mockReturnValueOnce(reply(401));
      const res = await request(http).put('/api/ai/key').set(bearer(me)).send({ apiKey: USER_KEY }).expect(400);
      expect(res.body.message).toMatch(/rejected/i);
      expect((await request(http).get('/api/ai/key').set(bearer(me))).body).toEqual({ hasKey: false });
    });

    it('rejects an unknown model name', async () => {
      fetchMock.mockReturnValueOnce(reply(404));
      await request(http).put('/api/ai/key').set(bearer(me)).send({ apiKey: USER_KEY, model: 'nope-1' }).expect(400);
    });

    it('saves a valid key, hides it, and stores it encrypted', async () => {
      fetchMock.mockReturnValueOnce(reply(200));
      const res = await request(http).put('/api/ai/key').set(bearer(me)).send({ apiKey: USER_KEY }).expect(200);
      expect(res.body).toMatchObject({ hasKey: true, keyHint: '...wxyz', model: null });
      expect(JSON.stringify(res.body)).not.toContain('USERSECRETKEY');

      // the validation probe used the user's key and was cheap
      const [, init] = fetchMock.mock.calls[0];
      expect(init.headers['x-api-key']).toBe(USER_KEY);
      expect(JSON.parse(init.body).max_tokens).toBe(1);

      const get = await request(http).get('/api/ai/key').set(bearer(me)).expect(200);
      expect(JSON.stringify(get.body)).not.toContain('USERSECRETKEY');

      const rows = await app.get(DataSource).query('SELECT * FROM user_ai_settings');
      expect(rows).toHaveLength(1);
      expect(JSON.stringify(rows)).not.toContain('USERSECRETKEY');
      expect(decryptKey(rows[0].encryptedKey, 'test-secret')).toBe(USER_KEY);
    });

    it('uses the key for that user only', async () => {
      const st = await request(http).get('/api/ai/status').set(bearer(me)).expect(200);
      expect(st.body).toEqual({ provider: 'anthropic', model: 'claude-sonnet-5-5', keySource: 'user' });

      fetchMock.mockReturnValueOnce(reply(200, 'Polished text.'));
      const res = await request(http).post('/api/ai/improve').set(bearer(me)).send({ text: 'draft text' }).expect(200);
      expect(res.body).toMatchObject({ text: 'Polished text.', keySource: 'user' });
      expect(fetchMock.mock.calls[0][1].headers['x-api-key']).toBe(USER_KEY);

      // another user still gets the offline provider and no network call
      fetchMock.mockClear();
      const o = await request(http).post('/api/ai/improve').set(bearer(other)).send({ text: 'draft text' }).expect(200);
      expect(o.body).toMatchObject({ provider: 'local', keySource: 'none' });
      expect(fetchMock).not.toHaveBeenCalled();
      expect((await request(http).get('/api/ai/key').set(bearer(other))).body).toEqual({ hasKey: false });
    });

    it('lets the user change their model and replace the key', async () => {
      const patched = await request(http).patch('/api/ai/key').set(bearer(me)).send({ model: 'claude-custom' }).expect(200);
      expect(patched.body.model).toBe('claude-custom');
      fetchMock.mockReturnValueOnce(reply(200, 'x'));
      await request(http).post('/api/ai/improve').set(bearer(me)).send({ text: 'hi there' }).expect(200);
      expect(JSON.parse(fetchMock.mock.calls[0][1].body).model).toBe('claude-custom');

      fetchMock.mockClear();
      fetchMock.mockReturnValueOnce(reply(200));
      const newKey = 'sk-ant-api03-REPLACEMENTKEY-9999';
      const res = await request(http).put('/api/ai/key').set(bearer(me)).send({ apiKey: newKey, model: 'claude-custom' }).expect(200);
      expect(res.body.keyHint).toBe('...9999');
      expect(await app.get(DataSource).query('SELECT id FROM user_ai_settings')).toHaveLength(1); // replaced, not duplicated
    });

    it('can skip validation, and still saves when Anthropic is unreachable', async () => {
      const key = 'sk-ant-api03-OFFLINEKEY-00001111';
      await request(http).put('/api/ai/key').set(bearer(other)).send({ apiKey: key, validate: false }).expect(200);
      expect(fetchMock).not.toHaveBeenCalled();

      fetchMock.mockRejectedValueOnce(new Error('network down'));
      await request(http).put('/api/ai/key').set(bearer(other)).send({ apiKey: key + 'x' }).expect(200);
      expect((await request(http).get('/api/ai/key').set(bearer(other))).body.keyHint).toBe('...111x');
    });

    it('PATCH needs a saved key; DELETE removes it and falls back to offline', async () => {
      const fresh = await register(app, 'freshuser');
      await request(http).patch('/api/ai/key').set(bearer(fresh)).send({ model: 'x-model' }).expect(400);

      await request(http).delete('/api/ai/key').set(bearer(me)).expect(204);
      expect((await request(http).get('/api/ai/key').set(bearer(me))).body).toEqual({ hasKey: false });
      const st = await request(http).get('/api/ai/status').set(bearer(me)).expect(200);
      expect(st.body).toMatchObject({ provider: 'local', keySource: 'none' });
      await request(http).delete('/api/ai/key').set(bearer(me)).expect(204); // idempotent
    });

    it('surfaces a revoked user key as 502 without echoing secrets', async () => {
      fetchMock.mockReturnValueOnce(reply(200));
      await request(http).put('/api/ai/key').set(bearer(me)).send({ apiKey: USER_KEY }).expect(200);
      fetchMock.mockReturnValueOnce(reply(401, 'invalid x-api-key sk-ant-api03-USERSECRETKEY'));
      const res = await request(http).post('/api/ai/improve').set(bearer(me)).send({ text: 'hello' }).expect(502);
      expect(JSON.stringify(res.body)).not.toContain('USERSECRETKEY');
    });
  });

  describe('with a server key', () => {
    it("prefers the user's key, and falls back to the server key after removal", async () => {
      const app = await boot({ ANTHROPIC_API_KEY: SERVER_KEY, AI_PROVIDER: 'auto' });
      try {
        const http = app.getHttpServer();
        const me = await register(app, 'meuser2');
        const improve = () => request(http).post('/api/ai/improve').set(bearer(me)).send({ text: 'hello world' });

        fetchMock.mockReturnValueOnce(reply(200, 'a'));
        expect((await improve().expect(200)).body.keySource).toBe('server');
        expect(fetchMock.mock.calls[0][1].headers['x-api-key']).toBe(SERVER_KEY);

        fetchMock.mockReturnValueOnce(reply(200)); // validation probe
        await request(http).put('/api/ai/key').set(bearer(me)).send({ apiKey: USER_KEY }).expect(200);
        fetchMock.mockReturnValueOnce(reply(200, 'b'));
        expect((await improve().expect(200)).body.keySource).toBe('user');
        expect(fetchMock.mock.calls[2][1].headers['x-api-key']).toBe(USER_KEY);

        await request(http).delete('/api/ai/key').set(bearer(me)).expect(204);
        fetchMock.mockReturnValueOnce(reply(200, 'c'));
        expect((await improve().expect(200)).body.keySource).toBe('server');
        expect(fetchMock.mock.calls[3][1].headers['x-api-key']).toBe(SERVER_KEY);
      } finally {
        await app.close();
      }
    });
  });

  describe('key encryption', () => {
    it('round-trips, uses a fresh IV, and fails closed with the wrong secret or tampering', () => {
      const a = encryptKey(USER_KEY, 's1');
      const b = encryptKey(USER_KEY, 's1');
      expect(a).not.toBe(b);
      expect(a).not.toContain('USERSECRETKEY');
      expect(decryptKey(a, 's1')).toBe(USER_KEY);
      expect(decryptKey(a, 's2')).toBeNull();
      expect(decryptKey(a.slice(0, -3) + 'AAA', 's1')).toBeNull();
      expect(decryptKey('garbage', 's1')).toBeNull();
    });
  });
});
