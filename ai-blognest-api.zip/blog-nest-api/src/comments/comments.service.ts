import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AuthUser } from '../common/auth-user';
import { PostsService } from '../posts/posts.service';
import { Role } from '../users/user.entity';
import { Comment } from './comment.entity';

const PUBLIC_AUTHOR = { id: true, username: true } as const;

@Injectable()
export class CommentsService {
  constructor(
    @InjectRepository(Comment) private readonly comments: Repository<Comment>,
    private readonly posts: PostsService,
  ) {}

  async listForPost(postId: number, user?: AuthUser) {
    await this.posts.findOne(String(postId), user); // 404s if missing or not visible
    return this.comments.find({
      where: { postId },
      relations: { author: true },
      select: { author: PUBLIC_AUTHOR, id: true, content: true, postId: true, createdAt: true },
      order: { createdAt: 'ASC', id: 'ASC' },
    });
  }

  async create(postId: number, content: string, user: AuthUser) {
    await this.posts.findOne(String(postId), user);
    const saved = await this.comments.save(
      this.comments.create({ postId, content, authorId: user.id }),
    );
    return this.findPublic(saved.id);
  }

  async remove(id: number, user: AuthUser): Promise<void> {
    const comment = await this.comments.findOne({ where: { id } });
    if (!comment) throw new NotFoundException('Comment not found');
    if (comment.authorId !== user.id && user.role !== Role.Admin) {
      throw new ForbiddenException('You can only delete your own comments');
    }
    await this.comments.remove(comment);
  }

  private findPublic(id: number) {
    return this.comments.findOne({
      where: { id },
      relations: { author: true },
      select: { author: PUBLIC_AUTHOR, id: true, content: true, postId: true, createdAt: true },
    });
  }
}
