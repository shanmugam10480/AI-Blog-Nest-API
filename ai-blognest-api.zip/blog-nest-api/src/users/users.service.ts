import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Role, User } from './user.entity';

@Injectable()
export class UsersService {
  constructor(@InjectRepository(User) private readonly users: Repository<User>) {}

  async create(data: { email: string; username: string; passwordHash: string }): Promise<User> {
    const email = data.email.toLowerCase();
    if (await this.users.exists({ where: { email } })) {
      throw new ConflictException('Email is already registered');
    }
    if (await this.users.exists({ where: { username: data.username } })) {
      throw new ConflictException('Username is already taken');
    }
    // The very first account becomes the admin so there is always someone who can moderate.
    const isFirst = (await this.users.count()) === 0;
    const user = await this.users.save(
      this.users.create({ ...data, email, role: isFirst ? Role.Admin : Role.User }),
    );
    return this.findById(user.id);
  }

  async findById(id: number): Promise<User> {
    const user = await this.users.findOne({ where: { id } });
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  /** Includes passwordHash – only for credential checks. */
  findByEmailWithPassword(email: string): Promise<User | null> {
    return this.users
      .createQueryBuilder('user')
      .addSelect('user.passwordHash')
      .where('user.email = :email', { email: email.toLowerCase() })
      .getOne();
  }
}
