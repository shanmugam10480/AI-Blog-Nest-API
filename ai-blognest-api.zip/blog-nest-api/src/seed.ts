import { NestFactory } from '@nestjs/core';
import * as bcrypt from 'bcryptjs';
import { AppModule } from './app.module';
import { PostsService } from './posts/posts.service';
import { UsersService } from './users/users.service';

/** `npm run seed` – creates an admin, a regular user and a few sample posts. */
async function seed() {
  const app = await NestFactory.createApplicationContext(AppModule, { logger: ['error'] });
  const users = app.get(UsersService);
  const posts = app.get(PostsService);

  const hash = await bcrypt.hash('password123', 10);
  const admin = await users.create({ email: 'admin@example.com', username: 'admin', passwordHash: hash });
  await users.create({ email: 'jane@example.com', username: 'jane', passwordHash: hash });
  const author = { id: admin.id, username: admin.username, role: admin.role };

  await posts.create(
    {
      title: 'Welcome to Blog Nest',
      content: 'This is the first post. Edit it, delete it, or write your own via the API.',
      tags: ['welcome', 'nestjs'],
      published: true,
    },
    author,
  );
  await posts.create(
    {
      title: 'Why NestJS?',
      content: 'Modules, dependency injection and decorators make large APIs easy to organise.',
      tags: ['nestjs', 'typescript'],
      published: true,
    },
    author,
  );
  await posts.create(
    { title: 'A draft post', content: 'Only the author and admins can see this one.', published: false },
    author,
  );

  console.log('Seeded. Log in with admin@example.com / password123 (admin) or jane@example.com / password123');
  await app.close();
}
seed().catch((err) => {
  console.error(err.message ?? err);
  process.exit(1);
});
