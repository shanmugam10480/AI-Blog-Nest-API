import { Controller, Get } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ApiTags } from '@nestjs/swagger';
import { Repository } from 'typeorm';
import { Tag } from './tag.entity';

@ApiTags('tags')
@Controller('tags')
export class TagsController {
  constructor(@InjectRepository(Tag) private readonly tags: Repository<Tag>) {}

  /** All tags that are used by at least one published post, with usage counts. */
  @Get()
  async list() {
    const rows = await this.tags
      .createQueryBuilder('tag')
      .innerJoin('tag.posts', 'post', 'post.published = :pub', { pub: true })
      .select(['tag.id AS id', 'tag.name AS name', 'COUNT(post.id) AS postCount'])
      .groupBy('tag.id')
      .orderBy('tag.name', 'ASC')
      .getRawMany();
    return rows.map((r) => ({ id: Number(r.id), name: r.name, postCount: Number(r.postCount) }));
  }
}
