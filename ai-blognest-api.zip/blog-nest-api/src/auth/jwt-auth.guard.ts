import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { AuthUser } from '../common/auth-user';

function extractToken(request: any): string | undefined {
  const [type, token] = (request.headers?.authorization ?? '').split(' ');
  return type === 'Bearer' ? token : undefined;
}

/** Requires a valid `Authorization: Bearer <token>` header. */
@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(private readonly jwt: JwtService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const token = extractToken(request);
    if (!token) throw new UnauthorizedException('Missing bearer token');
    try {
      const payload = await this.jwt.verifyAsync(token);
      request.user = { id: payload.sub, username: payload.username, role: payload.role } as AuthUser;
    } catch {
      throw new UnauthorizedException('Invalid or expired token');
    }
    return true;
  }
}

/** Attaches the user when a valid token is sent, but lets anonymous requests through. */
@Injectable()
export class OptionalJwtGuard implements CanActivate {
  constructor(private readonly jwt: JwtService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const token = extractToken(request);
    if (token) {
      try {
        const payload = await this.jwt.verifyAsync(token);
        request.user = { id: payload.sub, username: payload.username, role: payload.role } as AuthUser;
      } catch {
        // Treat a bad token as anonymous on public routes.
      }
    }
    return true;
  }
}
