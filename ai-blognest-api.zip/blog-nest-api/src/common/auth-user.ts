import { Role } from '../users/user.entity';

export interface AuthUser {
  id: number;
  username: string;
  role: Role;
}
