import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';
import { setupApp } from './setup-app';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  setupApp(app);

  const swaggerConfig = new DocumentBuilder()
    .setTitle('AI Blog Nest API')
    .setDescription('A blog REST API (users, posts, tags, comments) with AI writing tools: draft, summarize, tag, title and improve.')
    .setVersion('1.0')
    .addBearerAuth()
    .build();
  SwaggerModule.setup('docs', app, SwaggerModule.createDocument(app, swaggerConfig));

  const port = process.env.PORT ?? 3000;
  await app.listen(port);
  console.log(`AI Blog Nest API running on http://localhost:${port}/api`);
  console.log(`Swagger docs at        http://localhost:${port}/docs`);
}
bootstrap();
