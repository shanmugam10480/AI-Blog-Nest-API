import { Body, Controller, Delete, Get, HttpCode, Patch, Put, Param, ParseIntPipe, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { AuthUser } from '../common/auth-user';
import { CurrentUser } from '../common/current-user.decorator';
import { AiRateLimitGuard } from './ai-rate-limit.guard';
import { AiKeysService } from './ai-keys.service';
import { AiService } from './ai.service';
import {
  EnrichPostDto,
  GeneratePostDto,
  ImproveDto,
  SetApiKeyDto,
  SetModelDto,
  SuggestTagsDto,
  SuggestTitlesDto,
  SummarizeDto,
} from './dto/ai.dto';

@ApiTags('ai')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, AiRateLimitGuard)
@Controller('ai')
export class AiController {
  constructor(
    private readonly ai: AiService,
    private readonly keys: AiKeysService,
  ) {}

  /** Which provider/model is active (`local` when no ANTHROPIC_API_KEY is configured). */
  @Get('status')
  status(@CurrentUser() user: AuthUser) {
    return this.ai.status(user);
  }

  // ---- your own API key ------------------------------------------------------

  /** Whether you saved a key (only its last 4 characters are ever shown). */
  @Get('key')
  getKey(@CurrentUser() user: AuthUser) {
    return this.keys.get(user.id);
  }

  /** Save or replace YOUR Anthropic API key. It takes priority over the server key for your requests. */
  @Put('key')
  setKey(@Body() dto: SetApiKeyDto, @CurrentUser() user: AuthUser) {
    return this.keys.set(user.id, dto.apiKey, dto.model, dto.validate ?? true);
  }

  /** Change the model used with your key (null = server default). */
  @Patch('key')
  setModel(@Body() dto: SetModelDto, @CurrentUser() user: AuthUser) {
    return this.keys.setModel(user.id, dto.model ?? null);
  }

  /** Remove your key; requests fall back to the server key or the offline provider. */
  @Delete('key')
  @HttpCode(204)
  async removeKey(@CurrentUser() user: AuthUser) {
    await this.keys.remove(user.id);
  }

  /** Draft a whole post (title, excerpt, Markdown body, tags). Nothing is saved; send it to POST /posts. */
  @Post('generate-post')
  @HttpCode(200)
  generatePost(@Body() dto: GeneratePostDto, @CurrentUser() user: AuthUser) {
    return this.ai.generatePost(dto, user);
  }

  @Post('summarize')
  @HttpCode(200)
  summarize(@Body() dto: SummarizeDto, @CurrentUser() user: AuthUser) {
    return this.ai.summarize(dto, user);
  }

  @Post('suggest-tags')
  @HttpCode(200)
  suggestTags(@Body() dto: SuggestTagsDto, @CurrentUser() user: AuthUser) {
    return this.ai.suggestTags(dto, user);
  }

  @Post('suggest-titles')
  @HttpCode(200)
  suggestTitles(@Body() dto: SuggestTitlesDto, @CurrentUser() user: AuthUser) {
    return this.ai.suggestTitles(dto, user);
  }

  /** Rewrite text for grammar, clarity, brevity or tone. */
  @Post('improve')
  @HttpCode(200)
  improve(@Body() dto: ImproveDto, @CurrentUser() user: AuthUser) {
    return this.ai.improve(dto, user);
  }

  /** Generate an excerpt + tags for a post; `{ "apply": true }` saves them (author/admin only). */
  @Post('posts/:id/enrich')
  @HttpCode(200)
  enrich(@Param('id', ParseIntPipe) id: number, @Body() dto: EnrichPostDto, @CurrentUser() user: AuthUser) {
    return this.ai.enrich(id, dto, user);
  }
}
