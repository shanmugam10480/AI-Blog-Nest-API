import { CanActivate, ExecutionContext, HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

/**
 * Per-user sliding-window limiter for the AI endpoints (they cost money when a paid provider is on).
 * In memory, so it is per server instance; use a shared store (e.g. Redis) when running several.
 * Configure with AI_RATE_LIMIT_PER_MINUTE (default 20, 0 disables).
 */
@Injectable()
export class AiRateLimitGuard implements CanActivate {
  private readonly hits = new Map<number, number[]>();
  private readonly limit: number;

  constructor(config: ConfigService) {
    this.limit = Number(config.get('AI_RATE_LIMIT_PER_MINUTE', 20));
  }

  canActivate(context: ExecutionContext): boolean {
    if (!this.limit) return true;
    const req = context.switchToHttp().getRequest();
    const res = context.switchToHttp().getResponse();
    const userId: number | undefined = req.user?.id;
    if (userId === undefined) return true; // JwtAuthGuard runs first and rejects anonymous calls

    const now = Date.now();
    const recent = (this.hits.get(userId) ?? []).filter((t) => now - t < 60_000);
    if (recent.length >= this.limit) {
      const retryAfter = Math.max(1, Math.ceil((60_000 - (now - recent[0])) / 1000));
      res.setHeader('Retry-After', String(retryAfter));
      throw new HttpException(
        `AI rate limit reached (${this.limit}/minute). Try again in ${retryAfter}s.`,
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }
    recent.push(now);
    this.hits.set(userId, recent);
    return true;
  }
}
