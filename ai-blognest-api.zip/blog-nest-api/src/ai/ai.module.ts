import { Logger, Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from '../auth/auth.module';
import { PostsModule } from '../posts/posts.module';
import { AiKeysService } from './ai-keys.service';
import { UserAiSettings } from './user-ai-settings.entity';
import { AiRateLimitGuard } from './ai-rate-limit.guard';
import { AiController } from './ai.controller';
import { AiService } from './ai.service';
import { AI_PROVIDER, AiProvider } from './ai.types';
import { AnthropicProvider } from './providers/anthropic.provider';
import { LocalProvider } from './providers/local.provider';

/**
 * AI_PROVIDER = auto (default) | anthropic | local
 *  - auto: Anthropic when ANTHROPIC_API_KEY is set, otherwise the offline local provider.
 *  - AI_MODEL overrides the Claude model.
 */
export function createProvider(config: ConfigService): AiProvider {
  const choice = config.get<string>('AI_PROVIDER', 'auto');
  const apiKey = config.get<string>('ANTHROPIC_API_KEY');
  const logger = new Logger('AiModule');

  if (choice === 'local' || (choice === 'auto' && !apiKey)) {
    logger.log('Using the offline local AI provider (set ANTHROPIC_API_KEY for Claude).');
    return new LocalProvider();
  }
  if (!apiKey) throw new Error('AI_PROVIDER=anthropic requires ANTHROPIC_API_KEY');
  const model = config.get<string>('AI_MODEL', 'claude-sonnet-5-5');
  logger.log(`Using Anthropic model ${model}.`);
  return new AnthropicProvider({ apiKey, model, timeoutMs: Number(config.get('AI_TIMEOUT_MS', 60000)) });
}

@Module({
  imports: [AuthModule, PostsModule, TypeOrmModule.forFeature([UserAiSettings])],
  controllers: [AiController],
  providers: [
    AiService,
    AiKeysService,
    AiRateLimitGuard,
    { provide: AI_PROVIDER, inject: [ConfigService], useFactory: createProvider },
  ],
})
export class AiModule {}
