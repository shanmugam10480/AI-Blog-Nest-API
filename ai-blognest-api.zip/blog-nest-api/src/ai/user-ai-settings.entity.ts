import { Column, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

/** A user's own Anthropic API key (encrypted at rest) and optional model preference. */
@Entity('user_ai_settings')
export class UserAiSettings {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  userId: number;

  /** AES-256-GCM payload (`iv.tag.ciphertext`, base64). Never returned by the API. */
  @Column({ type: 'text', select: false })
  encryptedKey: string;

  /** Last 4 characters of the key, for display only. */
  @Column()
  keyHint: string;

  @Column({ type: 'varchar', nullable: true })
  model: string | null;

  @UpdateDateColumn()
  updatedAt: Date;
}
