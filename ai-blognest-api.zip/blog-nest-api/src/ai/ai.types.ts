export const AI_PROVIDER = Symbol('AI_PROVIDER');

export type Tone = 'professional' | 'casual' | 'friendly' | 'technical';
export type Length = 'short' | 'medium' | 'long';
export type ImproveGoal = 'grammar' | 'clarity' | 'concise' | 'friendly' | 'professional';

export interface GeneratePostInput {
  topic: string;
  tone: Tone;
  length: Length;
  audience?: string;
  keywords: string[];
}

export interface GeneratedPost {
  title: string;
  excerpt: string;
  /** Markdown body (does not repeat the title). */
  content: string;
  tags: string[];
}

/**
 * Anything that can power the AI endpoints. `LocalProvider` works offline with simple heuristics;
 * `AnthropicProvider` calls Claude. The service normalises whatever a provider returns, so
 * providers don't have to worry about limits (tag length, excerpt length, ...).
 */
export interface AiProvider {
  readonly name: string;
  readonly model: string;
  generatePost(input: GeneratePostInput): Promise<GeneratedPost>;
  summarize(text: string, maxSentences: number): Promise<string>;
  suggestTags(text: string, max: number): Promise<string[]>;
  suggestTitles(text: string, count: number): Promise<string[]>;
  improve(text: string, goal: ImproveGoal): Promise<string>;
}
