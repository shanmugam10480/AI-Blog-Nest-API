import { BadRequestException, Injectable } from '@nestjs/common';
import { AuthUser } from '../common/auth-user';
import { PostsService } from '../posts/posts.service';
import { AiKeysService } from './ai-keys.service';
import { AiProvider, GeneratedPost } from './ai.types';
import {
  EnrichPostDto,
  GeneratePostDto,
  ImproveDto,
  MAX_TEXT_CHARS,
  SourceDto,
  SuggestTagsDto,
  SuggestTitlesDto,
  SummarizeDto,
} from './dto/ai.dto';
import { truncate } from './providers/text-utils';

/** Keeps provider output within what the posts API accepts (tags <= 30 chars, excerpt <= 300 ...). */
export function normalizeTags(tags: string[], max: number): string[] {
  const clean = tags
    .map((t) =>
      String(t)
        .toLowerCase()
        .replace(/^#/, '')
        .replace(/[^a-z0-9+# -]/g, '')
        .trim()
        .replace(/\s+/g, '-')
        .slice(0, 30),
    )
    .filter(Boolean);
  return [...new Set(clean)].slice(0, max);
}

@Injectable()
export class AiService {
  constructor(
    private readonly keys: AiKeysService,
    private readonly posts: PostsService,
  ) {}

  /** Picks the user's own key first, then the server key, then the offline provider. */
  private async use(user: AuthUser): Promise<{ provider: AiProvider; meta: Record<string, string> }> {
    const { provider, keySource } = await this.keys.resolve(user.id);
    return { provider, meta: { provider: provider.name, model: provider.model, keySource } };
  }

  async status(user: AuthUser) {
    return (await this.use(user)).meta;
  }

  async generatePost(dto: GeneratePostDto, user: AuthUser) {
    const { provider, meta } = await this.use(user);
    const result = await provider.generatePost({
      topic: dto.topic,
      tone: dto.tone ?? 'friendly',
      length: dto.length ?? 'medium',
      audience: dto.audience,
      keywords: dto.keywords ?? [],
    });
    const post: GeneratedPost = {
      title: truncate(result.title.trim() || dto.topic.trim(), 200),
      excerpt: truncate(result.excerpt.trim(), 300),
      content: result.content.trim(),
      tags: normalizeTags(result.tags, 6),
    };
    return { ...post, ...meta };
  }

  async summarize(dto: SummarizeDto, user: AuthUser) {
    const text = await this.resolveText(dto, user);
    const { provider, meta } = await this.use(user);
    const summary = (await provider.summarize(text, dto.maxSentences ?? 3)).trim();
    return { summary, ...meta };
  }

  async suggestTags(dto: SuggestTagsDto, user: AuthUser) {
    const text = await this.resolveText(dto, user);
    const max = dto.max ?? 5;
    const { provider, meta } = await this.use(user);
    return { tags: normalizeTags(await provider.suggestTags(text, max), max), ...meta };
  }

  async suggestTitles(dto: SuggestTitlesDto, user: AuthUser) {
    const text = await this.resolveText(dto, user);
    const count = dto.count ?? 5;
    const { provider, meta } = await this.use(user);
    const titles = (await provider.suggestTitles(text, count))
      .map((t) => truncate(String(t).trim(), 200))
      .filter(Boolean)
      .slice(0, count);
    return { titles, ...meta };
  }

  async improve(dto: ImproveDto, user: AuthUser) {
    const { provider, meta } = await this.use(user);
    const text = (await provider.improve(dto.text, dto.goal ?? 'clarity')).trim();
    return { text, original: dto.text, ...meta };
  }

  /**
   * Generates an excerpt and tags for an existing post. With `apply: true` they are saved on the
   * post (tags are merged with the existing ones); only the author or an admin may do that.
   */
  async enrich(postId: number, dto: EnrichPostDto, user: AuthUser) {
    const post = await this.posts.findOne(String(postId), user); // 404 if not visible
    const text = this.postText(post.title, post.content);
    const { provider, meta } = await this.use(user);
    const excerpt = truncate((await provider.summarize(text, 2)).trim(), 300);
    const suggested = normalizeTags(await provider.suggestTags(text, 5), 5);
    const tags = normalizeTags([...(post.tags ?? []).map((t) => t.name), ...suggested], 10);

    let applied = false;
    if (dto.apply) {
      await this.posts.update(postId, { excerpt, tags }, user); // 403/404 unless author/admin
      applied = true;
    }
    return { postId, excerpt, tags, suggestedTags: suggested, applied, ...meta };
  }

  // ---- helpers -------------------------------------------------------------

  private postText(title: string, content: string): string {
    return `${title}\n\n${content}`.slice(0, MAX_TEXT_CHARS);
  }

  private async resolveText(source: SourceDto, user: AuthUser): Promise<string> {
    const hasText = source.text !== undefined;
    const hasPost = source.postId !== undefined;
    if (hasText === hasPost) throw new BadRequestException('Provide exactly one of "text" or "postId"');
    if (hasText) {
      if (!source.text.trim()) throw new BadRequestException('"text" must not be blank');
      return source.text;
    }
    const post = await this.posts.findOne(String(source.postId), user);
    return this.postText(post.title, post.content);
  }
}
