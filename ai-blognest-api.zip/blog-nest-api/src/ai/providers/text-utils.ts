const STOP_WORDS = new Set(
  `a about above after again all also am an and any are as at be because been before being below between both but by
   can could did do does doing done down during each few for from further get got had has have having he her here hers
   him his how i if in into is it its itself just like make made me more most my no nor not now of off on once one only
   or other our ours out over own same she should so some such than that the their theirs them then there these they this
   those through to too two under until up use used using very was we were what when where which while who whom why will
   with would you your yours really actually basically thing things way ways many much even still every lot lots`
    .split(/\s+/)
    .filter(Boolean),
);

/** Removes Markdown syntax so only readable prose is left. */
export function stripMarkdown(input: string): string {
  return input
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/`([^`]*)`/g, '$1')
    .replace(/^\s{0,3}#{1,6}\s+/gm, '')
    .replace(/^\s*>\s?/gm, '')
    .replace(/^\s*(?:[-*+]|\d+\.)\s+/gm, '')
    .replace(/[*_~]{1,3}([^*_~\n]+)[*_~]{1,3}/g, '$1')
    .replace(/\s+/g, ' ')
    .trim();
}

export function splitSentences(plain: string): string[] {
  const parts = plain
    .split(/(?<=[.!?])\s+(?=[A-Z0-9"'(])/)
    .map((s) => s.trim())
    .filter(Boolean);
  return parts.length ? parts : plain ? [plain] : [];
}

export function tokenize(text: string): string[] {
  return (text.toLowerCase().match(/[a-z][a-z0-9+#-]{2,}/g) ?? []).filter((w) => !STOP_WORDS.has(w));
}

/** Most frequent meaningful words, strongest first. `boost` text (e.g. a title) counts triple. */
export function topKeywords(text: string, limit: number, boost = ''): string[] {
  const counts = new Map<string, number>();
  const order = new Map<string, number>();
  const add = (word: string, weight: number) => {
    counts.set(word, (counts.get(word) ?? 0) + weight);
    if (!order.has(word)) order.set(word, order.size);
  };
  tokenize(boost).forEach((w) => add(w, 3));
  tokenize(text).forEach((w) => add(w, 1));
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || order.get(a[0])! - order.get(b[0])!)
    .slice(0, limit)
    .map(([w]) => w);
}

export function titleCase(input: string): string {
  const small = new Set(['a', 'an', 'the', 'and', 'or', 'but', 'of', 'to', 'in', 'on', 'for', 'with', 'vs']);
  return input
    .trim()
    .split(/\s+/)
    .map((w, i) => (i > 0 && small.has(w.toLowerCase()) ? w.toLowerCase() : w.charAt(0).toUpperCase() + w.slice(1)))
    .join(' ');
}

export function truncate(input: string, max: number): string {
  return input.length <= max ? input : `${input.slice(0, Math.max(0, max - 3)).trimEnd()}...`;
}
