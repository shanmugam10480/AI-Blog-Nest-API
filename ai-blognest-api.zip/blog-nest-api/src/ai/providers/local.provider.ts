import {
  AiProvider,
  GeneratedPost,
  GeneratePostInput,
  ImproveGoal,
  Tone,
} from '../ai.types';
import { splitSentences, stripMarkdown, titleCase, tokenize, topKeywords, truncate } from './text-utils';

const OPENERS: Record<Tone, string> = {
  professional: 'This article examines',
  casual: "Let's talk about",
  friendly: "Welcome! Today we're exploring",
  technical: 'This post is a practical walkthrough of',
};

const WORDY: Array<[RegExp, string]> = [
  [/\bin order to\b/gi, 'to'],
  [/\bdue to the fact that\b/gi, 'because'],
  [/\bat this point in time\b/gi, 'now'],
  [/\bin the event that\b/gi, 'if'],
  [/\bfor the purpose of\b/gi, 'for'],
  [/\ba large number of\b/gi, 'many'],
  [/\bhas the ability to\b/gi, 'can'],
  [/\bin spite of the fact that\b/gi, 'although'],
];

const FILLERS = /\b(?:very|really|basically|actually|just|quite|simply|literally)\s+/gi;

const CONTRACTIONS: Array<[RegExp, string]> = [
  [/\bdo not\b/gi, "don't"],
  [/\bdoes not\b/gi, "doesn't"],
  [/\bcannot\b/gi, "can't"],
  [/\bis not\b/gi, "isn't"],
  [/\bare not\b/gi, "aren't"],
  [/\bwill not\b/gi, "won't"],
  [/\bit is\b/gi, "it's"],
];

/**
 * Works offline with no API key: extractive summaries, keyword-based tags and titles, rule-based
 * text clean-up and a template-based draft generator. Useful for development, tests and as a
 * zero-cost fallback; use the Anthropic provider for genuinely written text.
 */
export class LocalProvider implements AiProvider {
  readonly name = 'local';
  readonly model = 'heuristics-v1';

  async generatePost(input: GeneratePostInput): Promise<GeneratedPost> {
    const topic = input.topic.trim().replace(/\s+/g, ' ');
    const words = topic.split(' ');
    const title = truncate(words.length >= 3 ? titleCase(topic) : `${titleCase(topic)}: A Practical Guide`, 200);
    const extra = input.keywords.map((k) => k.trim()).filter(Boolean);
    const keywords = [...new Set([...extra, ...topKeywords(topic, 4)])].slice(0, 5);
    const audience = input.audience ? ` for ${input.audience}` : '';
    const lower = topic.charAt(0).toLowerCase() + topic.slice(1);

    const intro = `${OPENERS[input.tone]} ${lower}${audience}. Whether you are just starting out or want to sharpen what you already know, the goal here is to leave you with a clear picture and a few concrete next steps.`;
    const sections: string[] = [intro];

    sections.push(
      `## Why this matters\n\nGetting this right saves time, avoids avoidable mistakes and makes it easier to explain your work to others. A small amount of upfront understanding pays off quickly.`,
    );

    if (input.length !== 'short') {
      const ideas = keywords.length
        ? keywords.map((k) => `- **${titleCase(k)}**: what it means in practice and where it fits in.`).join('\n')
        : '- **The basics**: what it is and why it exists.\n- **The trade-offs**: where it helps and where it does not.';
      sections.push(`## Key ideas\n\n${ideas}`);
    }

    sections.push(
      `## Getting started\n\n1. Define exactly what you want to achieve.\n2. Start with the smallest working example.\n3. Review the result and note what surprised you.\n4. Iterate, adding one improvement at a time.`,
    );

    if (input.length === 'long') {
      sections.push(
        `## Common mistakes to avoid\n\n- Skipping the fundamentals and jumping straight to advanced techniques.\n- Changing too many things at once, which makes problems hard to trace.\n- Not writing down what worked so you can repeat it.`,
        `## Going further\n\nOnce the basics feel natural, look for real examples, read how others approach it, and share your own experience. Teaching is one of the fastest ways to learn.`,
      );
    }

    sections.push(
      `## Conclusion\n\nThis does not have to be complicated. Take the first step today, keep notes as you go and refine your approach over time.`,
    );

    return {
      title,
      excerpt: truncate(intro, 300),
      content: sections.join('\n\n'),
      tags: keywords.length ? keywords : ['blogging'],
    };
  }

  async summarize(text: string, maxSentences: number): Promise<string> {
    const sentences = splitSentences(stripMarkdown(text));
    if (sentences.length <= maxSentences) return sentences.join(' ');

    const freq = new Map<string, number>();
    tokenize(sentences.join(' ')).forEach((w) => freq.set(w, (freq.get(w) ?? 0) + 1));

    const scored = sentences.map((sentence, index) => {
      const words = tokenize(sentence);
      const score = words.reduce((sum, w) => sum + (freq.get(w) ?? 0), 0) / Math.sqrt(words.length || 1);
      return { sentence, index, score: index === 0 ? score * 1.3 : score };
    });
    return scored
      .sort((a, b) => b.score - a.score)
      .slice(0, maxSentences)
      .sort((a, b) => a.index - b.index)
      .map((s) => s.sentence)
      .join(' ');
  }

  async suggestTags(text: string, max: number): Promise<string[]> {
    const firstLine = text.split('\n')[0] ?? '';
    return topKeywords(stripMarkdown(text), max, firstLine);
  }

  async suggestTitles(text: string, count: number): Promise<string[]> {
    const plain = stripMarkdown(text);
    const [k1, k2] = topKeywords(plain, 2, text.split('\n')[0] ?? '');
    const subject = titleCase(k1 ?? 'Your Topic');
    const templates = [
      `${subject}: A Practical Guide`,
      `Getting Started with ${subject}`,
      `What Everyone Should Know About ${subject}`,
      k2 ? `${subject} and ${titleCase(k2)}: Making Sense of Both` : `${subject} Explained Simply`,
      `Why ${subject} Matters`,
      `${subject} Explained Simply`,
      `Lessons Learned from ${subject}`,
      `A Beginner's Look at ${subject}`,
      `${subject}: Mistakes to Avoid`,
      `The Fast Track to ${subject}`,
    ];
    return [...new Set(templates)].slice(0, count);
  }

  async improve(text: string, goal: ImproveGoal): Promise<string> {
    let out = text.replace(/[ \t]+/g, ' ').replace(/ +([,.;:!?])/g, '$1').replace(/[ \t]+\n/g, '\n').trim();
    out = out.replace(/\b(\w+)(\s+\1\b)+/gi, '$1'); // "the the" -> "the"
    out = out.replace(/\bi\b/g, 'I');
    out = out.replace(/(^|[.!?]\s+|\n)([a-z])/g, (_m, pre, ch) => pre + ch.toUpperCase());
    out = out.replace(/([A-Za-z0-9])$/, '$1.'); // finish a trailing sentence

    if (goal === 'clarity' || goal === 'concise') WORDY.forEach(([re, to]) => (out = out.replace(re, to)));
    if (goal === 'concise') out = out.replace(FILLERS, '');
    if (goal === 'friendly') CONTRACTIONS.forEach(([re, to]) => (out = out.replace(re, to)));
    if (goal === 'professional') {
      out = out
        .replace(/\bdon't\b/gi, 'do not')
        .replace(/\bdoesn't\b/gi, 'does not')
        .replace(/\bcan't\b/gi, 'cannot')
        .replace(/\bisn't\b/gi, 'is not')
        .replace(/\bwon't\b/gi, 'will not');
    }
    // Re-capitalise sentence starts after replacements removed leading words.
    return out.replace(/(^|[.!?]\s+|\n)([a-z])/g, (_m, pre, ch) => pre + ch.toUpperCase());
  }
}
