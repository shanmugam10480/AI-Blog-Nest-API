import {
  ArrayMaxSize,
  IsArray,
  IsBoolean,
  IsIn,
  IsInt,
  Matches,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  MinLength,
} from 'class-validator';
import { ImproveGoal, Length, Tone } from '../ai.types';

export const MAX_TEXT_CHARS = 20000;

/** Provide the text directly, or the id of a post you are allowed to read. Exactly one of the two. */
export class SourceDto {
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(MAX_TEXT_CHARS)
  text?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  postId?: number;
}

export class SummarizeDto extends SourceDto {
  /** How many sentences the summary may have (default 3). */
  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(10)
  maxSentences?: number;
}

export class SuggestTagsDto extends SourceDto {
  /** Maximum number of tags (default 5). */
  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(10)
  max?: number;
}

export class SuggestTitlesDto extends SourceDto {
  /** Number of titles (default 5). */
  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(10)
  count?: number;
}

export class GeneratePostDto {
  @IsString()
  @MinLength(3)
  @MaxLength(300)
  topic: string;

  @IsOptional()
  @IsIn(['professional', 'casual', 'friendly', 'technical'])
  tone?: Tone;

  @IsOptional()
  @IsIn(['short', 'medium', 'long'])
  length?: Length;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  audience?: string;

  @IsOptional()
  @IsArray()
  @ArrayMaxSize(10)
  @IsString({ each: true })
  @MaxLength(50, { each: true })
  keywords?: string[];
}

export class ImproveDto {
  @IsString()
  @MinLength(1)
  @MaxLength(MAX_TEXT_CHARS)
  text: string;

  @IsOptional()
  @IsIn(['grammar', 'clarity', 'concise', 'friendly', 'professional'])
  goal?: ImproveGoal;
}

export class EnrichPostDto {
  /** When true, the generated excerpt and tags are saved on the post (author/admin only). */
  @IsOptional()
  @IsBoolean()
  apply?: boolean;
}

export class SetApiKeyDto {
  /** Your Anthropic API key (starts with `sk-ant-`). Stored encrypted; never shown again. */
  @IsString()
  @MinLength(20)
  @MaxLength(300)
  @Matches(/^\S+$/, { message: 'apiKey must not contain whitespace' })
  apiKey: string;

  /** Optional Claude model to use with your key (default: the server's AI_MODEL). */
  @IsOptional()
  @IsString()
  @MaxLength(100)
  @Matches(/^[A-Za-z0-9._:-]+$/, { message: 'model contains invalid characters' })
  model?: string;

  /** Verify the key with Anthropic before saving (default true). */
  @IsOptional()
  @IsBoolean()
  validate?: boolean;
}

export class SetModelDto {
  /** Model name, or null to go back to the server default. */
  @IsOptional()
  @IsString()
  @MaxLength(100)
  @Matches(/^[A-Za-z0-9._:-]+$/, { message: 'model contains invalid characters' })
  model?: string | null;
}
