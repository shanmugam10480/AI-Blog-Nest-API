import { BadRequestException, Inject, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AI_PROVIDER, AiProvider } from './ai.types';
import { decryptKey, encryptKey } from './key-crypto';
import { AnthropicProvider } from './providers/anthropic.provider';
import { UserAiSettings } from './user-ai-settings.entity';

export type KeySource = 'user' | 'server' | 'none';

export interface ResolvedProvider {
  provider: AiProvider;
  keySource: KeySource;
}

/** Decides which provider serves a request: the user's own key, else the server's, else offline. */
@Injectable()
export class AiKeysService {
  private readonly logger = new Logger(AiKeysService.name);

  constructor(
    @InjectRepository(UserAiSettings) private readonly repo: Repository<UserAiSettings>,
    private readonly config: ConfigService,
    @Inject(AI_PROVIDER) private readonly serverProvider: AiProvider,
  ) {}

  private get secret(): string {
    // Set AI_KEY_ENCRYPTION_SECRET in production so rotating JWT_SECRET doesn't orphan stored keys.
    return (
      this.config.get<string>('AI_KEY_ENCRYPTION_SECRET') ||
      this.config.get<string>('JWT_SECRET', 'dev-only-secret-change-me')
    );
  }

  private defaultModel(): string {
    return this.config.get<string>('AI_MODEL', 'claude-sonnet-5-5');
  }

  private timeout(): number {
    return Number(this.config.get('AI_TIMEOUT_MS', 60000));
  }

  async resolve(userId: number): Promise<ResolvedProvider> {
    const row = await this.repo
      .createQueryBuilder('s')
      .addSelect('s.encryptedKey')
      .where('s.userId = :userId', { userId })
      .getOne();
    if (row) {
      const apiKey = decryptKey(row.encryptedKey, this.secret);
      if (apiKey) {
        const provider = new AnthropicProvider({
          apiKey,
          model: row.model || this.defaultModel(),
          timeoutMs: this.timeout(),
        });
        return { provider, keySource: 'user' };
      }
      this.logger.warn(`Stored AI key for user ${userId} could not be decrypted; ignoring it.`);
    }
    return { provider: this.serverProvider, keySource: this.serverProvider.name === 'local' ? 'none' : 'server' };
  }

  async get(userId: number) {
    const row = await this.repo.findOne({ where: { userId } });
    if (!row) return { hasKey: false as const };
    return { hasKey: true as const, keyHint: `...${row.keyHint}`, model: row.model, updatedAt: row.updatedAt };
  }

  /** Saves (or replaces) the user's key. Verifies it with a 1-token call unless `validate` is false. */
  async set(userId: number, apiKey: string, model: string | undefined, validate: boolean) {
    const finalModel = model || null;
    if (validate) {
      const probe = new AnthropicProvider({
        apiKey,
        model: finalModel || this.defaultModel(),
        timeoutMs: Math.min(this.timeout(), 20_000),
      });
      const result = await probe.ping();
      if (result === 'rejected') throw new BadRequestException('Anthropic rejected this API key');
      if (result === 'bad-model') throw new BadRequestException('Anthropic does not recognise this model name');
      // 'unreachable' => don't block saving; the key is used and fails visibly later if wrong.
    }
    const existing = await this.repo.findOne({ where: { userId } });
    const row = existing ?? this.repo.create({ userId });
    row.encryptedKey = encryptKey(apiKey, this.secret);
    row.keyHint = apiKey.slice(-4);
    row.model = finalModel;
    await this.repo.save(row);
    return this.get(userId);
  }

  async setModel(userId: number, model: string | null) {
    const existing = await this.repo.findOne({ where: { userId } });
    if (!existing) throw new BadRequestException('Save an API key first');
    existing.model = model;
    await this.repo.save(existing);
    return this.get(userId);
  }

  async remove(userId: number): Promise<void> {
    await this.repo.delete({ userId });
  }
}
