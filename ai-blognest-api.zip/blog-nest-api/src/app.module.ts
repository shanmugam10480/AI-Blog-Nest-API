import { Controller, Get, Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { ApiTags } from '@nestjs/swagger';
import { TypeOrmModule } from '@nestjs/typeorm';
import { mkdirSync } from 'fs';
import { dirname } from 'path';
import { AiModule } from './ai/ai.module';
import { AuthModule } from './auth/auth.module';
import { CommentsModule } from './comments/comments.module';
import { PostsModule } from './posts/posts.module';
import { TagsModule } from './tags/tags.module';
import { UsersModule } from './users/users.module';

@ApiTags('health')
@Controller('health')
class HealthController {
  @Get()
  check() {
    return { status: 'ok', time: new Date().toISOString() };
  }
}

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => {
        const path = config.get<string>('DATABASE_PATH', 'data/blog.sqlite');
        const inMemory = path === ':memory:';
        if (!inMemory) mkdirSync(dirname(path), { recursive: true });
        return {
          // sql.js is pure JS/WASM: no native compilation needed on any OS.
          type: 'sqljs' as const,
          ...(inMemory ? {} : { location: path, autoSave: true }),
          autoLoadEntities: true,
          synchronize: true, // fine for a starter; switch to migrations for production data
        };
      },
    }),
    UsersModule,
    AuthModule,
    PostsModule,
    CommentsModule,
    TagsModule,
    AiModule,
  ],
  controllers: [HealthController],
})
export class AppModule {}
