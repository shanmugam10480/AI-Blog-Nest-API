import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository, SelectQueryBuilder } from 'typeorm';
import { AuthUser } from '../common/auth-user';
import { slugify } from '../common/slugify';
import { Comment } from '../comments/comment.entity';
import { Tag } from '../tags/tag.entity';
import { Role } from '../users/user.entity';
import { CreatePostDto } from './dto/create-post.dto';
import { QueryPostsDto } from './dto/query-posts.dto';
import { UpdatePostDto } from './dto/update-post.dto';
import { Post } from './post.entity';

@Injectable()
export class PostsService {
  constructor(
    @InjectRepository(Post) private readonly posts: Repository<Post>,
    @InjectRepository(Tag) private readonly tags: Repository<Tag>,
  ) {}

  /** Post + public author fields (id, username) + tags. Never exposes author email/role. */
  private baseQuery(): SelectQueryBuilder<Post> {
    return this.posts
      .createQueryBuilder('post')
      .leftJoin('post.author', 'author')
      .addSelect(['author.id', 'author.username'])
      .leftJoinAndSelect('post.tags', 'tag');
  }

  private applyVisibility(qb: SelectQueryBuilder<Post>, user?: AuthUser) {
    if (!user) {
      qb.andWhere('post.published = :pub', { pub: true });
    } else if (user.role !== Role.Admin) {
      qb.andWhere('(post.published = :pub OR post.authorId = :uid)', { pub: true, uid: user.id });
    }
    return qb;
  }

  async findAll(query: QueryPostsDto, user?: AuthUser) {
    const page = query.page ?? 1;
    const limit = query.limit ?? 10;
    const qb = this.applyVisibility(this.baseQuery(), user);

    if (query.q) {
      qb.andWhere('(post.title LIKE :q OR post.content LIKE :q)', { q: `%${query.q}%` });
    }
    if (query.tag) {
      qb.innerJoin('post.tags', 'filterTag', 'filterTag.name = :tagName', {
        tagName: query.tag.trim().toLowerCase(),
      });
    }
    if (query.authorId) {
      qb.andWhere('post.authorId = :authorId', { authorId: query.authorId });
    }

    const [items, total] = await qb
      .orderBy('post.createdAt', 'DESC')
      .addOrderBy('post.id', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return { items, meta: { total, page, limit, pages: Math.ceil(total / limit) } };
  }

  /** Accepts a numeric id or a slug. */
  async findOne(idOrSlug: string, user?: AuthUser): Promise<Post> {
    const isId = /^\d+$/.test(idOrSlug);
    const qb = this.applyVisibility(this.baseQuery(), user).andWhere(
      isId ? 'post.id = :key' : 'post.slug = :key',
      { key: isId ? Number(idOrSlug) : idOrSlug },
    );
    const post = await qb.getOne();
    if (!post) throw new NotFoundException('Post not found');
    return post;
  }

  async create(dto: CreatePostDto, user: AuthUser): Promise<Post> {
    const post = this.posts.create({
      title: dto.title,
      content: dto.content,
      excerpt: dto.excerpt ?? this.makeExcerpt(dto.content),
      published: dto.published ?? false,
      authorId: user.id,
      slug: await this.uniqueSlug(dto.title),
      tags: await this.resolveTags(dto.tags ?? []),
    });
    const saved = await this.posts.save(post);
    return this.findOne(String(saved.id), user);
  }

  async update(id: number, dto: UpdatePostDto, user: AuthUser): Promise<Post> {
    const post = await this.loadForWrite(id, user);
    if (dto.title !== undefined) post.title = dto.title;
    if (dto.content !== undefined) post.content = dto.content;
    if (dto.excerpt !== undefined) post.excerpt = dto.excerpt;
    if (dto.published !== undefined) post.published = dto.published;
    if (dto.tags !== undefined) post.tags = await this.resolveTags(dto.tags);
    await this.posts.save(post);
    return this.findOne(String(id), user);
  }

  async remove(id: number, user: AuthUser): Promise<void> {
    const post = await this.loadForWrite(id, user);
    await this.posts.manager.delete(Comment, { postId: post.id });
    await this.posts.remove(post);
  }

  // ---- helpers -------------------------------------------------------------

  /** Loads a post for modification; only its author or an admin may touch it. */
  private async loadForWrite(id: number, user: AuthUser): Promise<Post> {
    const post = await this.posts.findOne({ where: { id }, relations: { tags: true } });
    if (!post) throw new NotFoundException('Post not found');
    const allowed = post.authorId === user.id || user.role === Role.Admin;
    if (!allowed) {
      // Don't reveal that someone else's draft exists.
      if (!post.published) throw new NotFoundException('Post not found');
      throw new ForbiddenException('You can only modify your own posts');
    }
    return post;
  }

  private makeExcerpt(content: string): string {
    const plain = content.replace(/\s+/g, ' ').trim();
    return plain.length > 160 ? `${plain.slice(0, 157)}...` : plain;
  }

  private async uniqueSlug(title: string): Promise<string> {
    const base = slugify(title);
    let slug = base;
    for (let n = 2; await this.posts.exists({ where: { slug } }); n++) {
      slug = `${base}-${n}`;
    }
    return slug;
  }

  private async resolveTags(names: string[]): Promise<Tag[]> {
    const unique = [...new Set(names.map((n) => n.trim().toLowerCase()).filter(Boolean))];
    if (!unique.length) return [];
    const existing = await this.tags.find({ where: { name: In(unique) } });
    const have = new Set(existing.map((t) => t.name));
    const created = unique.filter((n) => !have.has(n)).map((name) => this.tags.create({ name }));
    return [...existing, ...(created.length ? await this.tags.save(created) : [])];
  }
}
